package manager;


public interface subject {
	
	public abstract  String getSubject();
	public abstract void setSubject(String subject);
}
