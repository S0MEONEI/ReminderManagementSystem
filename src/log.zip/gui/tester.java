package gui;

public class tester {
	
	public static void main(String[] args) {
		//WindowFrame frame = new WindowFrame(null);
		
		

	}
}
